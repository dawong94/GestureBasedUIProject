package marlin;

public class UC {

  public static int screenHeight = 800;
  public static int screenWidth = 1000;
}
